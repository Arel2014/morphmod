# 🐺 MorphMod — Fabric 1.21.1

İstediğin canlıya dönüş! Hayatta kalmada öldürdüklerini biriktir, yaratıcıda tüm canlılara eriş.

## ✨ Özellikler

| Özellik | Açıklama |
|---|---|
| 🎭 Dönüşüm | İstediğin Minecraft canlısına dönüşebilirsin |
| ❤️ Can & Zırh | O canlının can ve zırh değerleri gelir |
| 🏃 Hız | O canlının hareket hızı uygulanır |
| 🔊 Ses | Hasar/ölüm sesleri o canlının sesi olur |
| 🦅 Uçma | Yarasa, Phantom, Bee gibi canlılarda uçabilirsin |
| 🎮 Keybind | **M tuşu** ile menü açılır |

## 🎮 Nasıl Kullanılır?

### Hayatta Kalma Modu
- Bir canlıyı öldürdüğünde o canlıya dönüşme hakkı açılır
- **M** tuşuna bas → menüden seçim yap
- "İnsan (Sıfırla)" ile normale dön

### Yaratıcı Mod
- **M** tuşuna bas → tüm canlılar listelenir
- İstediğini seç, arama kutusunu kullan

## 🛠️ Kurulum ve Derleme

### Gereksinimler
- Java 21+
- Gradle (wrapper dahil)
- Fabric Loader 0.16.5+
- Fabric API 0.102.0+1.21.1

### Derleme
```bash
./gradlew build
```
Çıktı: `build/libs/morphmod-1.0.0.jar`

### Kurulum
1. `morphmod-1.0.0.jar` dosyasını `.minecraft/mods/` klasörüne at
2. `fabric-api` modunu da ekle
3. Minecraft'ı Fabric profili ile başlat

## 📁 Proje Yapısı
```
src/main/java/com/morphmod/
├── MorphMod.java           — Ana mod sınıfı (kill event, init)
├── MorphApplier.java       — Stat uygulama (can, hız, zırh, uçma)
├── MorphNetworking.java    — Server<->Client paket iletişimi
├── data/
│   └── MorphData.java      — Oyuncu başına morph verisi
├── client/
│   ├── MorphModClient.java — Client init, keybind, paket alma
│   └── MorphScreen.java    — Menü arayüzü (M tuşu GUI)
└── mixin/
    ├── PlayerEntityMixin.java       — Ses override
    ├── LivingEntityMixin.java       — Gelecek hook'lar
    └── ClientPlayerEntityMixin.java — Client hook'lar
```

## 🔮 Planlanan Özellikler
- [ ] Görsel model dönüşümü (entity render)
- [ ] Özel yetenekler (örü. Enderman teleport, Creeper patlama)
- [ ] NBT kayıt ile morph verisi kalıcılığı
- [ ] Multiplayer morph senkronizasyonu (diğer oyuncular görsün)
