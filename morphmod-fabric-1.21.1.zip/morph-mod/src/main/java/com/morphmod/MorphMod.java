package com.morphmod;

import com.morphmod.data.MorphData;
import com.morphmod.network.MorphRequestPayload;
import com.morphmod.network.MorphSyncPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MorphMod implements ModInitializer {

    public static final String MOD_ID = "morphmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final Identifier MORPH_REQUEST_ID = Identifier.of(MOD_ID, "morph_request");
    public static final Identifier MORPH_SYNC_ID = Identifier.of(MOD_ID, "morph_sync");

    @Override
    public void onInitialize() {
        LOGGER.info("MorphMod yükleniyor...");

        PayloadTypeRegistry.playC2S().register(MorphRequestPayload.ID, MorphRequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MorphSyncPayload.ID, MorphSyncPayload.CODEC);

        MorphNetworking.registerServerPackets();

        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, damageAmount) -> {
            if (damageSource.getAttacker() instanceof ServerPlayerEntity player) {
                String entityId = EntityType.getId(entity.getType()).toString();
                MorphData data = MorphData.get(player);
                data.addUnlockedMorph(entityId);
                MorphNetworking.syncMorphData(player);
            }
            return true;
        });

        LOGGER.info("MorphMod hazır!");
    }
}
