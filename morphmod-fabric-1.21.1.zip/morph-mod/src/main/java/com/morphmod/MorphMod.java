package com.morphmod;

import com.morphmod.data.MorphData;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MorphMod implements ModInitializer {

    public static final String MOD_ID = "morphmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Packet ID: client -> server: morph request
    public static final Identifier MORPH_REQUEST_ID = Identifier.of(MOD_ID, "morph_request");
    // Packet ID: server -> client: morph sync
    public static final Identifier MORPH_SYNC_ID = Identifier.of(MOD_ID, "morph_sync");

    @Override
    public void onInitialize() {
        LOGGER.info("MorphMod yükleniyor...");

        // Register network packets
        MorphNetworking.registerServerPackets();

        // When a living entity dies, give the killer its morph
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, damageAmount) -> {
            if (damageSource.getAttacker() instanceof ServerPlayerEntity player) {
                String entityId = EntityType.getId(entity.getType()).toString();
                MorphData data = MorphData.get(player);
                data.addUnlockedMorph(entityId);
                MorphNetworking.syncMorphData(player);
            }
            return true;
        });

        LOGGER.info("MorphMod hazır!");
    }
}
