package com.morphmod.client;

import com.morphmod.data.MorphData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class MorphScreen extends Screen {

    private final MorphData data;
    private final boolean isCreative;
    private List<String> allMorphs;
    private int scrollOffset = 0;
    private static final int ITEMS_PER_PAGE = 7;

    public MorphScreen(MorphData data, boolean isCreative) {
        super(Text.literal("Morph Seç"));
        this.data = data;
        this.isCreative = isCreative;
        buildMorphList();
    }

    private void buildMorphList() {
        if (isCreative) {
            allMorphs = Registries.ENTITY_TYPE.getIds().stream()
                    .map(Identifier::toString)
                    .sorted()
                    .collect(Collectors.toList());
        } else {
            allMorphs = new ArrayList<>(data.getUnlockedMorphs());
            Collections.sort(allMorphs);
        }
    }

    @Override
    protected void init() {
        super.init();
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearChildren();

        int startY = 55;
        int btnHeight = 22;
        int gap = 2;

        // Scroll up
        addDrawableChild(ButtonWidget.builder(Text.literal("▲"), btn -> {
            if (scrollOffset > 0) { scrollOffset--; rebuildButtons(); }
        }).dimensions(width / 2 + 115, startY, 20, 20).build());

        // Scroll down
        addDrawableChild(ButtonWidget.builder(Text.literal("▼"), btn -> {
            if (scrollOffset + ITEMS_PER_PAGE < allMorphs.size()) { scrollOffset++; rebuildButtons(); }
        }).dimensions(width / 2 + 115, startY + ITEMS_PER_PAGE * (btnHeight + gap), 20, 20).build());

        // Morph buttons
        int end = Math.min(scrollOffset + ITEMS_PER_PAGE, allMorphs.size());
        for (int i = scrollOffset; i < end; i++) {
            String morphId = allMorphs.get(i);
            String label = morphId.replace("minecraft:", "").replace("_", " ");
            String current = data.getCurrentMorph();
            String prefix = morphId.equals(current) ? "✔ " : "";
            final String finalMorphId = morphId;
            final int row = i - scrollOffset;
            addDrawableChild(ButtonWidget.builder(Text.literal(prefix + label), btn -> {
                MorphModClient.requestMorph(finalMorphId);
                close();
            }).dimensions(width / 2 - 110, startY + row * (btnHeight + gap), 220, btnHeight).build());
        }

        // İnsan butonu
        addDrawableChild(ButtonWidget.builder(Text.literal("🧍 İnsan (Sıfırla)"), btn -> {
            MorphModClient.requestMorph("none");
            close();
        }).dimensions(width / 2 - 70, startY + ITEMS_PER_PAGE * (btnHeight + gap) + 30, 140, 22).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        // Başlık
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("§6§lMorph Seç"), width / 2, 8, 0xFFFFFF);
        // Mod
        String modeText = isCreative ? "§a[Yaratıcı - Tüm Canlılar]" : "§e[Hayatta Kalma - Öldürdüklerin]";
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(modeText), width / 2, 22, 0xFFFFFF);
        // Sayı
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§7" + allMorphs.size() + " canlı | " + (scrollOffset / ITEMS_PER_PAGE + 1) + ". sayfa"),
                width / 2, 38, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
