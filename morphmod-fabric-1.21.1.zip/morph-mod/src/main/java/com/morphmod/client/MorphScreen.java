package com.morphmod.client;

import com.morphmod.data.MorphData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class MorphScreen extends Screen {

    private final MorphData data;
    private final boolean isCreative;
    private List<String> displayedMorphs;
    private int scrollOffset = 0;
    private static final int ITEMS_PER_PAGE = 8;
    private TextFieldWidget searchField;

    public MorphScreen(MorphData data, boolean isCreative) {
        super(Text.translatable("screen.morphmod.title"));
        this.data = data;
        this.isCreative = isCreative;
    }

    @Override
    protected void init() {
        super.init();

        // Search field
        searchField = new TextFieldWidget(textRenderer, width / 2 - 100, 30, 200, 20, Text.literal("Ara..."));
        searchField.setChangedListener(query -> {
            scrollOffset = 0;
            updateDisplayedMorphs(query);
        });
        addDrawableChild(searchField);

        updateDisplayedMorphs("");

        // Scroll buttons
        addDrawableChild(ButtonWidget.builder(Text.literal("▲"), btn -> {
            if (scrollOffset > 0) { scrollOffset--; refreshButtons(); }
        }).dimensions(width / 2 + 115, 60, 20, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▼"), btn -> {
            if (scrollOffset + ITEMS_PER_PAGE < displayedMorphs.size()) { scrollOffset++; refreshButtons(); }
        }).dimensions(width / 2 + 115, 60 + ITEMS_PER_PAGE * 25, 20, 20).build());

        // Human (reset) button
        addDrawableChild(ButtonWidget.builder(Text.literal("🧍 İnsan (Sıfırla)"), btn -> {
            MorphModClient.requestMorph("none");
            close();
        }).dimensions(width / 2 - 80, height - 30, 160, 20).build());

        refreshButtons();
    }

    private void updateDisplayedMorphs(String query) {
        Collection<String> source;
        if (isCreative) {
            // In creative: show all entity types
            source = Registries.ENTITY_TYPE.getIds().stream()
                    .map(Identifier::toString)
                    .sorted()
                    .collect(Collectors.toList());
        } else {
            source = data.getUnlockedMorphs();
        }

        String lowerQuery = query.toLowerCase(Locale.ROOT);
        displayedMorphs = source.stream()
                .filter(m -> lowerQuery.isEmpty() || m.contains(lowerQuery))
                .collect(Collectors.toList());

        refreshButtons();
    }

    private void refreshButtons() {
        // Remove old morph buttons (keep search, scroll, reset)
        clearChildren();
        init(); // re-init search + scroll + reset; morph buttons added below

        int startY = 60;
        int end = Math.min(scrollOffset + ITEMS_PER_PAGE, displayedMorphs.size());
        for (int i = scrollOffset; i < end; i++) {
            String morphId = displayedMorphs.get(i);
            String label = morphId.replace("minecraft:", "").replace("_", " ");
            // Highlight current morph
            String current = data.getCurrentMorph();
            String prefix = morphId.equals(current) ? "✔ " : "";
            int idx = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(prefix + label), btn -> {
                MorphModClient.requestMorph(morphId);
                close();
            }).dimensions(width / 2 - 110, startY + (idx - scrollOffset) * 25, 220, 22).build());
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFF);

        String modeText = isCreative ? "§a[Yaratıcı Modu - Tüm Canlılar]" : "§e[Hayatta Kalma - Öldürdüklerin]";
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(modeText), width / 2, 20, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
