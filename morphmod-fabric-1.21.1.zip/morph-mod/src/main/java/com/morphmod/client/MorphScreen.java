package com.morphmod.client;

import com.morphmod.data.MorphData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class MorphScreen extends Screen {

    private final MorphData data;
    private final boolean isCreative;
    private List<String> allMorphs;
    private int scrollOffset = 0;
    private static final int ITEMS_PER_PAGE = 8;
    private String searchQuery = "";

    public MorphScreen(MorphData data, boolean isCreative) {
        super(Text.translatable("screen.morphmod.title"));
        this.data = data;
        this.isCreative = isCreative;
        buildMorphList();
    }

    private void buildMorphList() {
        if (isCreative) {
            allMorphs = Registries.ENTITY_TYPE.getIds().stream()
                    .map(Identifier::toString)
                    .sorted()
                    .collect(Collectors.toList());
        } else {
            allMorphs = new ArrayList<>(data.getUnlockedMorphs());
            Collections.sort(allMorphs);
        }
    }

    private List<String> getFilteredMorphs() {
        if (searchQuery.isEmpty()) return allMorphs;
        String q = searchQuery.toLowerCase(Locale.ROOT);
        return allMorphs.stream().filter(m -> m.contains(q)).collect(Collectors.toList());
    }

    @Override
    protected void init() {
        super.init();
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearChildren();

        List<String> filtered = getFilteredMorphs();
        int startY = 50;

        // Scroll up button
        addDrawableChild(ButtonWidget.builder(Text.literal("▲"), btn -> {
            if (scrollOffset > 0) { scrollOffset--; rebuildButtons(); }
        }).dimensions(width / 2 + 115, startY, 20, 20).build());

        // Scroll down button
        addDrawableChild(ButtonWidget.builder(Text.literal("▼"), btn -> {
            if (scrollOffset + ITEMS_PER_PAGE < filtered.size()) { scrollOffset++; rebuildButtons(); }
        }).dimensions(width / 2 + 115, startY + ITEMS_PER_PAGE * 24, 20, 20).build());

        // Morph buttons
        int end = Math.min(scrollOffset + ITEMS_PER_PAGE, filtered.size());
        for (int i = scrollOffset; i < end; i++) {
            String morphId = filtered.get(i);
            String label = morphId.replace("minecraft:", "").replace("_", " ");
            String current = data.getCurrentMorph();
            String prefix = morphId.equals(current) ? "✔ " : "";
            final String finalMorphId = morphId;
            addDrawableChild(ButtonWidget.builder(Text.literal(prefix + label), btn -> {
                MorphModClient.requestMorph(finalMorphId);
                close();
            }).dimensions(width / 2 - 110, startY + (i - scrollOffset) * 24, 220, 20).build());
        }

        // Reset button
        addDrawableChild(ButtonWidget.builder(Text.literal("İnsan (Sıfırla)"), btn -> {
            MorphModClient.requestMorph("none");
            close();
        }).dimensions(width / 2 - 60, height - 35, 120, 20).build());

        // Search buttons (simple +/- for filter instead of text field to avoid recursion)
        addDrawableChild(ButtonWidget.builder(Text.literal("Aramayı Temizle"), btn -> {
            searchQuery = "";
            scrollOffset = 0;
            rebuildButtons();
        }).dimensions(width / 2 - 60, height - 60, 120, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFF);
        String modeText = isCreative ? "§a[Yaratıcı - Tüm Canlılar]" : "§e[Hayatta Kalma - Öldürdüklerin]";
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(modeText), width / 2, 22, 0xFFFFFF);
        List<String> filtered = getFilteredMorphs();
        context.drawCenteredTextWithShadow(textRenderer, 
            Text.literal("§7" + filtered.size() + " canlı | Sayfa " + (scrollOffset/ITEMS_PER_PAGE + 1)), 
            width / 2, 36, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
