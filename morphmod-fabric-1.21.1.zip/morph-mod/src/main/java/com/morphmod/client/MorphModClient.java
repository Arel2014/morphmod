package com.morphmod.client;

import com.morphmod.MorphMod;
import com.morphmod.data.MorphData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Environment(EnvType.CLIENT)
public class MorphModClient implements ClientModInitializer {

    public static KeyBinding openMenuKey;
    public static MorphData clientMorphData = new MorphData();

    @Override
    public void onInitializeClient() {
        // Register keybind: default M
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.morphmod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.morphmod"
        ));

        // Listen for key press -> open GUI
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openMenuKey.wasPressed() && client.player != null) {
                client.setScreen(new MorphScreen(clientMorphData, client.player.isCreative()));
            }
        });

        // Receive sync packet from server
        ClientPlayNetworking.registerGlobalReceiver(MorphMod.MORPH_SYNC_ID, (client, handler, buf, responseSender) -> {
            int count = buf.readInt();
            Set<String> morphs = new HashSet<>();
            for (int i = 0; i < count; i++) {
                morphs.add(buf.readString());
            }
            String current = buf.readString();

            client.execute(() -> {
                clientMorphData = new MorphData();
                clientMorphData.addAllMorphs(morphs);
                if (!current.equals("none")) {
                    clientMorphData.setCurrentMorph(current);
                }
            });
        });

        MorphMod.LOGGER.info("MorphMod client hazır!");
    }

    // Send morph request to server
    public static void requestMorph(String morphId) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(morphId);
        ClientPlayNetworking.send(MorphMod.MORPH_REQUEST_ID, buf);
    }
}
