package com.morphmod.client;

import com.morphmod.MorphMod;
import com.morphmod.data.MorphData;
import com.morphmod.network.MorphRequestPayload;
import com.morphmod.network.MorphSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;

@Environment(EnvType.CLIENT)
public class MorphModClient implements ClientModInitializer {

    public static KeyBinding openMenuKey;
    public static MorphData clientMorphData = new MorphData();

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.morphmod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.morphmod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openMenuKey.wasPressed() && client.player != null) {
                client.setScreen(new MorphScreen(clientMorphData, client.player.isCreative()));
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(MorphSyncPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                clientMorphData = new MorphData();
                clientMorphData.addAllMorphs(new HashSet<>(payload.unlockedMorphs()));
                if (!payload.currentMorph().equals("none")) {
                    clientMorphData.setCurrentMorph(payload.currentMorph());
                }
            });
        });

        MorphMod.LOGGER.info("MorphMod client hazır!");
    }

    public static void requestMorph(String morphId) {
        ClientPlayNetworking.send(new MorphRequestPayload(morphId));
    }
}
