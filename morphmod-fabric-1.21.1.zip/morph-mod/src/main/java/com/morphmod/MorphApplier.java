package com.morphmod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeRegistry;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class MorphApplier {

    /**
     * Applies the stats of the given entity type to the player.
     * morphId == null means revert to human.
     */
    public static void applyMorph(ServerPlayerEntity player, String morphId) {
        if (morphId == null || morphId.equals("none")) {
            // Reset to human defaults
            resetToHuman(player);
            return;
        }

        Identifier id = Identifier.tryParse(morphId);
        if (id == null) return;

        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        if (type == null) return;

        // Apply max health
        double maxHealth = getDefaultMaxHealth(type);
        EntityAttributeInstance healthAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(maxHealth);
            if (player.getHealth() > maxHealth) {
                player.setHealth((float) maxHealth);
            }
        }

        // Apply movement speed
        double speed = getDefaultSpeed(type);
        EntityAttributeInstance speedAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.setBaseValue(speed);
        }

        // Apply armor
        double armor = getDefaultArmor(type);
        EntityAttributeInstance armorAttr = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (armorAttr != null) {
            armorAttr.setBaseValue(armor);
        }

        // Flying ability: if entity type is naturally flying (bats, phantoms, bees, parrots, etc.)
        boolean canFly = isFlyingEntity(morphId);
        player.getAbilities().allowFlying = canFly || player.isCreative();
        player.getAbilities().flying = false;
        player.sendAbilitiesUpdate();

        MorphMod.LOGGER.info("{} -> {} morphuna dönüştü (can: {}, hız: {})", player.getName().getString(), morphId, maxHealth, speed);
    }

    private static void resetToHuman(ServerPlayerEntity player) {
        EntityAttributeInstance healthAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (healthAttr != null) healthAttr.setBaseValue(20.0);

        EntityAttributeInstance speedAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(0.1);

        EntityAttributeInstance armorAttr = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (armorAttr != null) armorAttr.setBaseValue(0.0);

        if (!player.isCreative() && !player.isSpectator()) {
            player.getAbilities().allowFlying = false;
            player.getAbilities().flying = false;
            player.sendAbilitiesUpdate();
        }
    }

    // Returns default max health for entity type
    private static double getDefaultMaxHealth(EntityType<?> type) {
        var attrs = DefaultAttributeRegistry.get(type);
        if (attrs == null) return 20.0;
        var attr = attrs.getCustomInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        return attr != null ? attr.getValue() : 20.0;
    }

    private static double getDefaultSpeed(EntityType<?> type) {
        var attrs = DefaultAttributeRegistry.get(type);
        if (attrs == null) return 0.1;
        var attr = attrs.getCustomInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        return attr != null ? attr.getValue() : 0.1;
    }

    private static double getDefaultArmor(EntityType<?> type) {
        var attrs = DefaultAttributeRegistry.get(type);
        if (attrs == null) return 0.0;
        var attr = attrs.getCustomInstance(EntityAttributes.GENERIC_ARMOR);
        return attr != null ? attr.getValue() : 0.0;
    }

    // Checks if an entity type is primarily a flying entity
    private static boolean isFlyingEntity(String morphId) {
        return switch (morphId) {
            case "minecraft:bat", "minecraft:phantom", "minecraft:bee",
                 "minecraft:parrot", "minecraft:allay", "minecraft:blaze",
                 "minecraft:wither", "minecraft:ender_dragon", "minecraft:vex",
                 "minecraft:ghast" -> true;
            default -> false;
        };
    }
}
