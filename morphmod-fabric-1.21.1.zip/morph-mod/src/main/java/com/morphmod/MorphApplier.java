package com.morphmod;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;

public class MorphApplier {

    public static void applyMorph(ServerPlayerEntity player, String morphId) {
        if (morphId == null || morphId.equals("none")) {
            resetToHuman(player);
            return;
        }

        double[] stats = getStatsForMorph(morphId);
        applyStats(player, stats[0], stats[1], stats[2]);

        boolean canFly = isFlyingEntity(morphId);
        player.getAbilities().allowFlying = canFly;
        if (!canFly) player.getAbilities().flying = false;
        player.sendAbilitiesUpdate();

        // Hitbox boyutu (entity dimensions)
        // Not: Minecraft'ta player hitbox'ı direkt değiştirilemiyor,
        // bu yüzden sadece istatistikleri uyguluyoruz
    }

    private static void applyStats(ServerPlayerEntity player, double health, double speed, double armor) {
        EntityAttributeInstance healthAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(health);
            if (player.getHealth() > health) player.setHealth((float) health);
        }
        EntityAttributeInstance speedAttr = player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(speed);
        EntityAttributeInstance armorAttr = player.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (armorAttr != null) armorAttr.setBaseValue(armor);
    }

    private static void resetToHuman(ServerPlayerEntity player) {
        applyStats(player, 20.0, 0.1, 0.0);
        player.getAbilities().allowFlying = false;
        player.getAbilities().flying = false;
        player.sendAbilitiesUpdate();
    }

    private static double[] getStatsForMorph(String morphId) {
        return switch (morphId) {
            case "minecraft:zombie", "minecraft:skeleton", "minecraft:husk",
                 "minecraft:stray", "minecraft:drowned" -> new double[]{20.0, 0.23, 2.0};
            case "minecraft:spider", "minecraft:cave_spider" -> new double[]{16.0, 0.3, 0.0};
            case "minecraft:creeper" -> new double[]{20.0, 0.25, 0.0};
            case "minecraft:enderman" -> new double[]{40.0, 0.3, 0.0};
            case "minecraft:blaze" -> new double[]{20.0, 0.23, 2.0};
            case "minecraft:ghast" -> new double[]{10.0, 0.4, 0.0};
            case "minecraft:witch" -> new double[]{26.0, 0.25, 0.0};
            case "minecraft:iron_golem" -> new double[]{100.0, 0.25, 6.0};
            case "minecraft:wither" -> new double[]{300.0, 0.6, 4.0};
            case "minecraft:ender_dragon" -> new double[]{200.0, 0.6, 0.0};
            case "minecraft:bat" -> new double[]{6.0, 0.4, 0.0};
            case "minecraft:bee" -> new double[]{10.0, 0.3, 0.0};
            case "minecraft:phantom" -> new double[]{20.0, 0.9, 0.0};
            case "minecraft:parrot" -> new double[]{6.0, 0.4, 0.0};
            case "minecraft:allay" -> new double[]{20.0, 0.6, 0.0};
            case "minecraft:vex" -> new double[]{14.0, 0.9, 0.0};
            case "minecraft:wolf" -> new double[]{8.0, 0.3, 0.0};
            case "minecraft:cat", "minecraft:ocelot" -> new double[]{10.0, 0.3, 0.0};
            case "minecraft:horse" -> new double[]{30.0, 0.338, 0.0};
            case "minecraft:cow", "minecraft:mooshroom" -> new double[]{10.0, 0.2, 0.0};
            case "minecraft:pig" -> new double[]{10.0, 0.25, 0.0};
            case "minecraft:sheep" -> new double[]{8.0, 0.23, 0.0};
            case "minecraft:chicken" -> new double[]{4.0, 0.25, 0.0};
            case "minecraft:squid", "minecraft:glow_squid" -> new double[]{10.0, 0.2, 0.0};
            case "minecraft:dolphin" -> new double[]{10.0, 0.4, 0.0};
            case "minecraft:turtle" -> new double[]{30.0, 0.117, 0.0};
            case "minecraft:axolotl" -> new double[]{14.0, 0.2, 0.0};
            case "minecraft:villager" -> new double[]{20.0, 0.5, 0.0};
            case "minecraft:wither_skeleton" -> new double[]{20.0, 0.25, 2.0};
            case "minecraft:piglin", "minecraft:piglin_brute" -> new double[]{16.0, 0.35, 2.0};
            case "minecraft:hoglin", "minecraft:zoglin" -> new double[]{40.0, 0.3, 2.0};
            case "minecraft:ravager" -> new double[]{100.0, 0.3, 50.0};
            default -> new double[]{20.0, 0.1, 0.0};
        };
    }

    public static boolean isFlyingEntity(String morphId) {
        return switch (morphId) {
            case "minecraft:bat", "minecraft:phantom", "minecraft:bee",
                 "minecraft:parrot", "minecraft:allay", "minecraft:blaze",
                 "minecraft:wither", "minecraft:ender_dragon", "minecraft:vex",
                 "minecraft:ghast" -> true;
            default -> false;
        };
    }
}
