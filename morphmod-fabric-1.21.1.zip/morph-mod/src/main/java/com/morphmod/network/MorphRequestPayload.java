package com.morphmod.network;

import com.morphmod.MorphMod;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record MorphRequestPayload(String morphId) implements CustomPayload {
    public static final Id<MorphRequestPayload> ID = new Id<>(MorphMod.MORPH_REQUEST_ID);
    public static final PacketCodec<PacketByteBuf, MorphRequestPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, MorphRequestPayload::morphId, MorphRequestPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
