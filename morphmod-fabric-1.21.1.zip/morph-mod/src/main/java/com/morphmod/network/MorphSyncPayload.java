package com.morphmod.network;

import com.morphmod.MorphMod;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

import java.util.ArrayList;
import java.util.List;

public record MorphSyncPayload(List<String> unlockedMorphs, String currentMorph) implements CustomPayload {
    public static final Id<MorphSyncPayload> ID = new Id<>(MorphMod.MORPH_SYNC_ID);
    public static final PacketCodec<PacketByteBuf, MorphSyncPayload> CODEC = new PacketCodec<>() {
        @Override
        public MorphSyncPayload decode(PacketByteBuf buf) {
            int count = buf.readInt();
            List<String> morphs = new ArrayList<>();
            for (int i = 0; i < count; i++) morphs.add(buf.readString());
            String current = buf.readString();
            return new MorphSyncPayload(morphs, current);
        }

        @Override
        public void encode(PacketByteBuf buf, MorphSyncPayload value) {
            buf.writeInt(value.unlockedMorphs().size());
            for (String m : value.unlockedMorphs()) buf.writeString(m);
            buf.writeString(value.currentMorph());
        }
    };

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
