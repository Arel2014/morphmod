package com.morphmod.mixin;

import com.morphmod.data.MorphData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin extends LivingEntity {

    protected PlayerEntityMixin() {
        super(null, null);
    }

    /**
     * Replaces the player's hurt sound with the morphed entity's hurt sound.
     */
    @Inject(method = "getHurtSound", at = @At("HEAD"), cancellable = true)
    private void morphHurtSound(net.minecraft.entity.damage.DamageSource source, CallbackInfoReturnable<SoundEvent> cir) {
        PlayerEntity player = (PlayerEntity)(Object)this;
        MorphData data = MorphData.get(player);
        if (data.isHuman()) return;

        String morphId = data.getCurrentMorph();
        Identifier id = Identifier.tryParse(morphId);
        if (id == null) return;
        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        if (type == null) return;

        // Create a dummy entity to get its hurt sound (safe approach)
        // We redirect to entity-specific sounds via registry lookup
        Identifier soundId = Identifier.of(id.getNamespace(), "entity." + id.getPath().replace("/", ".") + ".hurt");
        SoundEvent sound = Registries.SOUND_EVENT.get(soundId);
        if (sound != null) {
            cir.setReturnValue(sound);
        }
    }

    /**
     * Replaces the player's death sound with the morphed entity's death sound.
     */
    @Inject(method = "getDeathSound", at = @At("HEAD"), cancellable = true)
    private void morphDeathSound(CallbackInfoReturnable<SoundEvent> cir) {
        PlayerEntity player = (PlayerEntity)(Object)this;
        MorphData data = MorphData.get(player);
        if (data.isHuman()) return;

        String morphId = data.getCurrentMorph();
        Identifier id = Identifier.tryParse(morphId);
        if (id == null) return;

        Identifier soundId = Identifier.of(id.getNamespace(), "entity." + id.getPath().replace("/", ".") + ".death");
        SoundEvent sound = Registries.SOUND_EVENT.get(soundId);
        if (sound != null) {
            cir.setReturnValue(sound);
        }
    }
}
