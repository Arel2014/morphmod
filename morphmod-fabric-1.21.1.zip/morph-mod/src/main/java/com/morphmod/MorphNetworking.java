package com.morphmod;

import com.morphmod.data.MorphData;
import com.morphmod.network.MorphRequestPayload;
import com.morphmod.network.MorphSyncPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MorphNetworking {

    public static void registerServerPackets() {
        ServerPlayNetworking.registerGlobalReceiver(MorphRequestPayload.ID, (payload, context) -> {
            String requestedMorph = payload.morphId();
            context.server().execute(() -> {
                ServerPlayerEntity player = context.player();
                MorphData data = MorphData.get(player);
                boolean creative = player.isCreative();

                if (requestedMorph.equals("none")) {
                    data.setCurrentMorph(null);
                    MorphApplier.applyMorph(player, null);
                    syncMorphData(player);
                } else if (creative || data.getUnlockedMorphs().contains(requestedMorph)) {
                    data.setCurrentMorph(requestedMorph);
                    MorphApplier.applyMorph(player, requestedMorph);
                    syncMorphData(player);
                }
            });
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            syncMorphData(handler.getPlayer());
        });
    }

    public static void syncMorphData(ServerPlayerEntity player) {
        MorphData data = MorphData.get(player);
        Set<String> morphs = data.getUnlockedMorphs();
        List<String> morphList = new ArrayList<>(morphs);
        String current = data.getCurrentMorph() != null ? data.getCurrentMorph() : "none";
        ServerPlayNetworking.send(player, new MorphSyncPayload(morphList, current));
    }
}
