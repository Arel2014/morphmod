package com.morphmod;

import com.morphmod.data.MorphData;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Set;

public class MorphNetworking {

    public static void registerServerPackets() {
        // Listen for morph selection from client
        ServerPlayNetworking.registerGlobalReceiver(MorphMod.MORPH_REQUEST_ID, (server, player, handler, buf, responseSender) -> {
            String requestedMorph = buf.readString();
            server.execute(() -> {
                MorphData data = MorphData.get(player);
                boolean creative = player.isCreative();

                // In survival, must have unlocked the morph (or "none" to reset)
                if (requestedMorph.equals("none")) {
                    data.setCurrentMorph(null);
                    MorphApplier.applyMorph(player, null);
                    syncMorphData(player);
                } else if (creative || data.getUnlockedMorphs().contains(requestedMorph)) {
                    data.setCurrentMorph(requestedMorph);
                    MorphApplier.applyMorph(player, requestedMorph);
                    syncMorphData(player);
                }
            });
        });

        // Sync on join
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            syncMorphData(handler.getPlayer());
        });
    }

    public static void syncMorphData(ServerPlayerEntity player) {
        MorphData data = MorphData.get(player);
        PacketByteBuf buf = PacketByteBufs.create();

        Set<String> morphs = data.getUnlockedMorphs();
        buf.writeInt(morphs.size());
        for (String m : morphs) {
            buf.writeString(m);
        }
        String current = data.getCurrentMorph();
        buf.writeString(current != null ? current : "none");

        ServerPlayNetworking.send(player, MorphMod.MORPH_SYNC_ID, buf);
    }
}
