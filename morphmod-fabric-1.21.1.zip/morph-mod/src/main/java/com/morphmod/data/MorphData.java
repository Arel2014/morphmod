package com.morphmod.data;

import com.morphmod.MorphMod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;

import java.util.*;

/**
 * Stores morph data per player using a simple map keyed by player UUID.
 * On server side this is authoritative; on client side it's a sync'd copy.
 */
public class MorphData {

    private static final Map<UUID, MorphData> SERVER_DATA = new HashMap<>();

    private final Set<String> unlockedMorphs = new LinkedHashSet<>();
    private String currentMorph = null; // null = human

    public static MorphData get(PlayerEntity player) {
        return SERVER_DATA.computeIfAbsent(player.getUuid(), id -> new MorphData());
    }

    public static MorphData getOrCreate(UUID uuid) {
        return SERVER_DATA.computeIfAbsent(uuid, id -> new MorphData());
    }

    public void addUnlockedMorph(String entityId) {
        unlockedMorphs.add(entityId);
        MorphMod.LOGGER.info("Yeni morph açıldı: {}", entityId);
    }

    public void addAllMorphs(Collection<String> ids) {
        unlockedMorphs.addAll(ids);
    }

    public Set<String> getUnlockedMorphs() {
        return Collections.unmodifiableSet(unlockedMorphs);
    }

    public String getCurrentMorph() {
        return currentMorph;
    }

    public void setCurrentMorph(String morphId) {
        this.currentMorph = morphId;
    }

    public boolean isHuman() {
        return currentMorph == null;
    }

    // NBT serialization for persistence
    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        NbtList list = new NbtList();
        for (String id : unlockedMorphs) {
            list.add(NbtString.of(id));
        }
        nbt.put("unlocked", list);
        if (currentMorph != null) {
            nbt.putString("current", currentMorph);
        }
        return nbt;
    }

    public void fromNbt(NbtCompound nbt) {
        unlockedMorphs.clear();
        NbtList list = nbt.getList("unlocked", 8); // 8 = string type
        for (int i = 0; i < list.size(); i++) {
            unlockedMorphs.add(list.getString(i));
        }
        if (nbt.contains("current")) {
            currentMorph = nbt.getString("current");
        } else {
            currentMorph = null;
        }
    }
}
